
import UIKit

class ViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var viewIncorrectPassword: UIView!
    @IBOutlet weak var viewEmail: UIView!
    @IBOutlet weak var viewPassword: UIView!
    @IBOutlet weak var viewLogIn: UIView!
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
        
    override func viewDidLoad() {
        super.viewDidLoad()
        
        viewMain.roundedView()
        viewIncorrectPassword.roundedView()
        viewEmail.roundedView()
        viewPassword.roundedView()
        viewLogIn.roundedView()
        
        viewMain.viewBorder()
        viewEmail.viewBorder()
        viewPassword.viewBorder()
        
        viewIncorrectPassword.isHidden = true

        txtEmail.delegate = self
        txtPassword.delegate = self
        
        navigationController?.setNavigationBarHidden(true, animated: true)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    
    @IBAction func btnLogInAction(_ sender: Any) {
        GlobalFunction.shared.AuthenticateUser(username: txtEmail.text!, password: txtPassword.text!) { (response) in
            if response["token"].exists() {
                self.viewIncorrectPassword.isHidden = true
                self.performSegue(withIdentifier: "segList", sender: self)
            } else {
                self.viewIncorrectPassword.isHidden = false
            }
        }
    }
}

extension UIView {
    func roundedView() {
        self.layer.cornerRadius = 5
        self.clipsToBounds = true
    }
    
    func viewBorder() {
        self.layer.borderWidth = 1
        self.layer.borderColor = UIColor.black.cgColor
    }
}
