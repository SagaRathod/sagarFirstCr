
import UIKit
import Alamofire
import SwiftyJSON
import Kingfisher

class UserListViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var tableView: UITableView!
    
    private let refreshControl = UIRefreshControl()
    var arrUserData = [JSON]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.delegate = self
        tableView.dataSource = self
        
        if #available(iOS 10.0, *) {
            tableView.refreshControl = refreshControl
        } else {
            tableView.addSubview(refreshControl)
        }
        
        refreshControl.addTarget(self, action: #selector(refreshWeatherData(_:)), for: .valueChanged)
        fetchUserData()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @objc private func refreshWeatherData(_ sender: Any) {
        fetchUserData()
    }
    
    func fetchUserData() {
        let finalUrl = "https://reqres.in/api/users?page=2"
        self.refreshControl.beginRefreshing()
        APIManager.shared.requestGETURL(strURL: finalUrl, success: { (response) in
            DispatchQueue.main.async {
                self.arrUserData = response["data"].arrayValue
                self.tableView.reloadData()
                self.refreshControl.endRefreshing()
            }
        }) { (error) in
            print(error)
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrUserData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "mycell")
        
        let imgAvatar: UIImageView = cell?.viewWithTag(1) as! UIImageView
        let lblName: UILabel = cell?.viewWithTag(2) as! UILabel
        let lblEmail: UILabel = cell?.viewWithTag(3) as! UILabel
        
        imgAvatar.kf.setImage(with: URL(string: arrUserData[indexPath.row]["avatar"].stringValue))
        lblName.text = arrUserData[indexPath.row]["first_name"].stringValue + arrUserData[indexPath.row]["last_name"].stringValue
        lblEmail.text = arrUserData[indexPath.row]["email"].stringValue
        
        return cell!
    }
    
}
