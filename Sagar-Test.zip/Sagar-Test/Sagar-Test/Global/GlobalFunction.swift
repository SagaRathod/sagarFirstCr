
import UIKit
import Alamofire
import SwiftyJSON

class GlobalFunction: NSObject {

    static let shared = GlobalFunction()
    
    static let requestHeaders :[String : String] = ["Content-Type":"application/json"]

    func AuthenticateUser(username:String,password:String, completion: @escaping (_ result: JSON) -> ())  {
        let finalUrl = "https://reqres.in/api/login"
        let  paramter : Parameters = [ "email": username,
                                       "password": password
        ]
        
        APIManager.shared.requestPOSTURL(strURL: finalUrl, params: paramter, headers: GlobalFunction.requestHeaders, success: { (respons) in
            print(respons)
            completion (respons)
        }) { (Error) in
            completion (JSON(Error))
            print( "AuthenticateUser === \(Error)")
        }
    }
    
}
